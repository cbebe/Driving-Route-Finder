#ifndef _SERVER_H_
#define _SERVER_H_

#include <iostream>
#include <list>
#include "dijkstra.h"
#include "readgraph.h"

#endif